# 第三期字幕稿 · 开场修订版

118秒；先交代交通场景与本期题目，再展开模型；无旁白。8–11.8秒为清楚展示的双语片名，不叠加重复字幕。

| 起止秒 | 中文 | English |
| --- | --- | --- |
| 0.6–3.9 | 4000辆车，都要从起点开到终点。 | 4,000 cars all need to reach the same destination. |
| 4.2–7.7 | 多修一条近路，能更快到达吗？ | Would adding a shortcut get everyone there sooner? |
| 12–15.6 | 先看原路：车越多，某些路越慢。 | First, the original roads: some get slower as more cars use them. |
| 16–19.4 | 上下两条路线，各走2000辆。 | Two routes, with 2,000 cars on each. |
| 20–23.5 | 上路：20加45，共65分钟。 | Upper route: 20 + 45 = 65 minutes. |
| 24–27.5 | 下路：45加20，也是65分钟。 | Lower route: 45 + 20 = 65 minutes. |
| 27.8–30.8 | 换一条路线，并不能更快。 | Switching routes gives no time advantage. |
| 32–35.7 | 现在，打开一条A到B的近路。 | Now open a shortcut from A to B. |
| 36–39.8 | 刚开放时，看起来只要约40分钟。 | At first, the new route looks like about 40 minutes. |
| 40.2–43.3 | 这只是原有车流附近的估算。 | That estimate is near the original traffic split. |
| 44–47.5 | 越来越多人，改走这条近路。 | More and more drivers choose the shortcut. |
| 48–52 | 两段路都挤进了更多车辆。 | Both variable roads take on more cars. |
| 52.5–56.1 | 车越多，两段耗时就越长。 | As their loads grow, so do their travel times. |
| 56.6–60.2 | 近路仍诱人，大家继续往里走。 | The shortcut still looks better to each driver. |
| 61–64.2 | 直到4000辆车，全走近路。 | Eventually all 4,000 cars use the new route. |
| 65–68.5 | 40加0加40，一共80分钟。 | 40 + 0 + 40 = 80 minutes. |
| 69–73 | 一个人改回上路，要85分钟。 | One driver switching to the upper route takes 85. |
| 74–78.4 | 改回下路，同样要85分钟。 | Switching alone to the lower route also takes 85. |
| 79–82.5 | 大家都慢了，单独换路却更慢。 | Everyone is slower, yet switching alone is worse. |
| 83–86.9 | 关掉近路，再让车辆重新分流。 | Close the shortcut, then let traffic split again. |
| 87.3–91.1 | 各回2000辆，又是65分钟。 | Back to 2,000 per route and 65 minutes. |
| 92–96 | 多一条路，所有人反而多花15分钟。 | With the extra link, everyone loses 15 minutes. |
| 96.4–99.8 | 这就是布雷斯悖论。 | This is Braess’s paradox. |
| 100.4–104.1 | 对自己最快的选择， | The fastest choice for each individual |
| 104.4–109.1 | 未必带来对所有人最快的结果。 | need not produce the fastest outcome for everyone. |
| 110–113.6 | 它只会出现在特定路网和条件下。 | It requires particular networks and traffic conditions. |
| 114–117.8 | 不代表修路一定会更堵。 | It does not mean that road building always makes things worse. |
