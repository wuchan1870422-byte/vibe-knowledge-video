# 第二期字幕稿

《没有发动机，谁在推这艘船？》 · 125秒 · 无旁白

用户已明确授权自主制作，不等待中途确认。

| 起止秒 | 中文 | English |
| --- | --- | --- |
| 0.7–3.5 | 没有风。没有发动机。 | No wind. No engine. |
| 3.8–6.7 | 也没有人推它。 | And no one is pushing. |
| 7.1–10.0 | 没有发动机，谁在推它？ | No engine. What moves this boat? |
| 10.5–14.0 | 答案，藏在船尾。 | The answer is at the stern. |
| 14.3–18.0 | 一小块樟脑，接触着水。 | A small piece of camphor touches the water. |
| 21.0–25.0 | 分子不断释放，进入水与界面。 | Molecules enter the water and its surface. |
| 25.3–29.3 | 随机运动，把分子扩散开。 | Random motion spreads them by diffusion. |
| 30.1–34.2 | 船尾附近，樟脑分子更多。 | More camphor accumulates near the stern. |
| 34.5–38.8 | 这些分子改变了界面自由能。 | These molecules change the interfacial free energy. |
| 39.1–43.1 | 在这里，水面的张力降低。 | Here, the surface tension falls. |
| 43.4–47.5 | 前方较高，后方较低。 | Higher ahead. Lower behind. |
| 48.0–52.2 | 差异沿水面分布，形成梯度。 | A variation along the surface creates a gradient. |
| 52.5–55.4 | 它既有大小，也有方向。 | The gradient has both magnitude and direction. |
| 57.0–61.0 | 水面从低张力处流向高张力处。 | The surface flows from low to high tension. |
| 61.4–65.5 | 这就是马兰戈尼效应。 | This is the Marangoni effect. |
| 66.0–70.0 | 但水的流向，不等于船的受力。 | Water flow and force on the boat are different. |
| 70.4–74.5 | 前后张力不对称，产生向前合力。 | Unequal tension creates a forward resultant. |
| 75.0–79.5 | 合力与水动力，共同决定运动。 | Capillary and hydrodynamic forces set the motion. |
| 81.0–85.0 | 樟脑的储量，却是有限的。 | The supply of camphor is finite. |
| 85.4–89.4 | 释放减弱，前后差异逐渐缩小。 | As release weakens, the difference fades. |
| 89.8–93.8 | 驱动变弱，阻力让小船减速。 | Less drive. Drag slows the boat. |
| 94.2–98.5 | 供给耗尽，运动最终停下。 | When the supply runs out, motion dies away. |
| 100.0–103.5 | 它没有发动机。 | It has no engine. |
| 104.0–107.5 | 但它并非没有能量来源。 | But it does have an energy source. |
| 108.0–111.8 | 樟脑释放，消耗化学自由能。 | Camphor release spends chemical free energy. |
| 112.1–115.8 | 维持不均匀，也在持续耗散。 | Maintaining the gradient also dissipates energy. |
| 116.1–119.5 | 这是非平衡系统，不是永动机。 | A nonequilibrium system, not perpetual motion. |
| 120.0–124.6 | 真正驱动它的，是水面上微小的不均匀。 | What moves it is a tiny imbalance at the surface. |
